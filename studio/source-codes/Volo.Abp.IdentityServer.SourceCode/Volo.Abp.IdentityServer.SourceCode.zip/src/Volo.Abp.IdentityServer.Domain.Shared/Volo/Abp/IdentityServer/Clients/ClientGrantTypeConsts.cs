﻿namespace Volo.Abp.IdentityServer.Clients
{
    public class ClientGrantTypeConsts
    {
        public static int GrantTypeMaxLength { get; set; } =  250;
    }
}
