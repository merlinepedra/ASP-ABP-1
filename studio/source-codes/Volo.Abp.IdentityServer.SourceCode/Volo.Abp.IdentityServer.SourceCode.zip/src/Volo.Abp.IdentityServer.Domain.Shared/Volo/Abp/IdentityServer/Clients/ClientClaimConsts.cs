﻿namespace Volo.Abp.IdentityServer.Clients
{
    public class ClientClaimConsts
    {
        public static int TypeMaxLength { get; set; } =  250;

        public static int ValueMaxLength { get; set; } =  250;
    }
}
