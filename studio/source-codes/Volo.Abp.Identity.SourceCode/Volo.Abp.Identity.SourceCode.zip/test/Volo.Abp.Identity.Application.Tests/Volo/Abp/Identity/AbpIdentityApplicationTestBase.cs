﻿namespace Volo.Abp.Identity
{
    public class AbpIdentityApplicationTestBase : AbpIdentityExtendedTestBase<AbpIdentityApplicationTestModule>
    {

    }
}
