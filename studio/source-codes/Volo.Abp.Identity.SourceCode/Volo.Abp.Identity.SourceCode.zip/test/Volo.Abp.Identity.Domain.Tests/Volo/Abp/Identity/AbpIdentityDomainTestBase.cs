﻿namespace Volo.Abp.Identity
{
    public abstract class AbpIdentityDomainTestBase : AbpIdentityExtendedTestBase<AbpIdentityDomainTestModule>
    {
        
    }
}
