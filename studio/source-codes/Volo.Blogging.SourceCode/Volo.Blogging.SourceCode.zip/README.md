# Blogging Module

This module adds a simple blog to your ABP application;

* Allows to create multiple blogs in a single application.
* Supports the Markdown format.
* Allows to write comment for a post.
* Allows to assign tags to the blog posts.

See the [blog.abp.io](https://blog.abp.io/) website as a live example of the blogging module.