﻿using System;
using System.Collections.Generic;
using System.Text;
using Volo.Abp.Modularity;

namespace Volo.Abp.AuditLogging
{
    public class AuditLogging_Repository_Resolve_Tests<TStartupModule> : AuditLoggingTestBase<TStartupModule>
        where TStartupModule : IAbpModule
    {

    }
}
