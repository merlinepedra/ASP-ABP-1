﻿namespace Volo.Abp.PermissionManagement
{
    public class PermissionManagementRemoteServiceConsts
    {
        public const string RemoteServiceName = "AbpPermissionManagement";

        public const string ModuleName = "permissionManagement";
    }
}
