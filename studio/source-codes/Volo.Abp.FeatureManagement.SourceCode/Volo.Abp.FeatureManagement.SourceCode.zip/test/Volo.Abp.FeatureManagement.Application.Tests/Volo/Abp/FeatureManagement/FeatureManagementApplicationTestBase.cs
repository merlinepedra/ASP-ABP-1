﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volo.Abp.FeatureManagement
{
    public class FeatureManagementApplicationTestBase : FeatureManagementTestBase<FeatureManagementApplicationTestModule>
    {

    }
}
