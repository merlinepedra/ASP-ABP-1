﻿namespace Volo.Abp.FeatureManagement
{
    public class FeatureProviderDto
    {
        public string Name { get; set; }

        public string Key { get; set; }
    }
}
