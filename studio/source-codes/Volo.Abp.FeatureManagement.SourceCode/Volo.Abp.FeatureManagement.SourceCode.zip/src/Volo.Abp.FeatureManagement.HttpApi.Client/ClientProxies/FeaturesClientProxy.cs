// This file is part of FeaturesClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.FeatureManagement.ClientProxies
{
    public partial class FeaturesClientProxy
    {
    }
}
