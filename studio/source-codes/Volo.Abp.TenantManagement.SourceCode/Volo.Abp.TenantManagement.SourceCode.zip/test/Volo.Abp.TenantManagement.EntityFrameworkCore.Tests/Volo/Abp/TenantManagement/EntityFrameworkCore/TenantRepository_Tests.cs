﻿namespace Volo.Abp.TenantManagement.EntityFrameworkCore
{
    public class TenantRepository_Tests : TenantRepository_Tests<AbpTenantManagementEntityFrameworkCoreTestModule>
    {

    }
}
