# abp-settingmanagement
Setting management module for ABP framework.
