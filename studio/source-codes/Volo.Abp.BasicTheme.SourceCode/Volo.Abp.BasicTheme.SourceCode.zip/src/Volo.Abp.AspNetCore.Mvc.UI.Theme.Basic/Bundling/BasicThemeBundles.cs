﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Theme.Basic.Bundling
{
    public static class BasicThemeBundles
    {
        public static class Styles
        {
            public const string Global = "Basic.Global";
        }

        public static class Scripts
        {
            public const string Global = "Basic.Global";
        }
    }
}