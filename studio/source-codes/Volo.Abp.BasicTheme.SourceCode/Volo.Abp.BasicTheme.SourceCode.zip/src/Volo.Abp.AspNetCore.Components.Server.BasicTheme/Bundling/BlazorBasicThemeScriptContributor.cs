﻿using Volo.Abp.AspNetCore.Mvc.UI.Bundling;

namespace Volo.Abp.AspNetCore.Components.Server.BasicTheme.Bundling
{
    public class BlazorBasicThemeScriptContributor : BundleContributor
    {

    }
}