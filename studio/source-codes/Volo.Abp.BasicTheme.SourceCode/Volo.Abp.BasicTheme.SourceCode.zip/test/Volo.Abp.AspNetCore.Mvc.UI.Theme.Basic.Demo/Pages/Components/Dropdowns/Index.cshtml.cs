using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Volo.Abp.AspNetCore.Mvc.UI.Theme.Basic.Demo.Pages.Components.Dropdowns
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}