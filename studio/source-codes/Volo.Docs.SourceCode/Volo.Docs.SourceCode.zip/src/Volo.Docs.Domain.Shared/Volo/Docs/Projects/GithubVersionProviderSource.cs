﻿namespace Volo.Docs.Projects
{
    public enum GithubVersionProviderSource
    {
        Releases,
        Branches
    }
}
