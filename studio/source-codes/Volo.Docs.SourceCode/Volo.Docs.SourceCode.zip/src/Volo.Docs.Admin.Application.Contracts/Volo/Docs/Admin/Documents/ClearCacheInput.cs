﻿using System;

namespace Volo.Docs.Admin.Documents
{
    public class ClearCacheInput
    {
        public Guid ProjectId { get; set; }
    }
}
