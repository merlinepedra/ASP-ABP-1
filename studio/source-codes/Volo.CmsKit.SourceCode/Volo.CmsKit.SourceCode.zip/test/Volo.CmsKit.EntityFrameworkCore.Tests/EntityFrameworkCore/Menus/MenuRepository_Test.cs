using Volo.CmsKit.Menus;

namespace Volo.CmsKit.EntityFrameworkCore.Menus
{
    public class MenuRepository_Test : MenuItemRepository_Test<CmsKitEntityFrameworkCoreTestModule>
    {
        
    }
}