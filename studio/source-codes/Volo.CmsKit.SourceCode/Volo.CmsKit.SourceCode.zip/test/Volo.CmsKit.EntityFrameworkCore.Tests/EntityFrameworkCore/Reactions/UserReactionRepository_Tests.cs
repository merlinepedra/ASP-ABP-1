﻿using Volo.CmsKit.Reactions;

namespace Volo.CmsKit.EntityFrameworkCore.Reactions
{
    public class UserReactionRepository_Tests : UserReactionRepository_Tests<CmsKitEntityFrameworkCoreTestModule>
    {
    }
}
