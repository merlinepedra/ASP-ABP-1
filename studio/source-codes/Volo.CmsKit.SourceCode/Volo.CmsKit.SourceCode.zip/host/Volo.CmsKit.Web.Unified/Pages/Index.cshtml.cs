using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Volo.CmsKit.Pages
{
    public class IndexModel : PageModel
    {

    }
}
