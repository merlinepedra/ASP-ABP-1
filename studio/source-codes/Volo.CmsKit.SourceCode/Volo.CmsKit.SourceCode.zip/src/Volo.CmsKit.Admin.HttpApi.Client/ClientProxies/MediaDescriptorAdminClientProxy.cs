// This file is part of MediaDescriptorAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Admin.MediaDescriptors.ClientProxies
{
    public partial class MediaDescriptorAdminClientProxy
    {
    }
}
