﻿namespace Volo.CmsKit.Web
{
    public class CmsKitUiCommentOptions
    {
        public bool IsReactionsEnabled { get; set; }

        public CmsKitUiCommentOptions()
        {
            IsReactionsEnabled = true;
        }
    }
}
