﻿namespace Volo.CmsKit.Admin
{
    public class CmsKitAdminRemoteServiceConsts
    {
        public const string RemoteServiceName = "CmsKitAdmin";

        public const string ModuleName = "cms-kit-admin";
    }
}
