﻿using Volo.Abp.BlobStoring;

namespace Volo.CmsKit.MediaDescriptors
{
    [BlobContainerName("cms-kit-media")]
    public class MediaContainer
    {
        
    }
}