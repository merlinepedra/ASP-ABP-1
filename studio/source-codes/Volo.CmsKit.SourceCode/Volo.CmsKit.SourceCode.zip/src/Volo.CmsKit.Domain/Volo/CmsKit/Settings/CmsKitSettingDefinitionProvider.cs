﻿using Volo.Abp.Settings;

namespace Volo.CmsKit.Settings
{
    public class CmsKitSettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            /* Define module settings here.
             * Use names from CmsKitSettings class.
             */
        }
    }
}