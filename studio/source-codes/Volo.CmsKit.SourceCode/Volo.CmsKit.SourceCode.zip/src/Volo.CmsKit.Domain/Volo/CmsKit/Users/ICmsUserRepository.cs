﻿using Volo.Abp.Users;

namespace Volo.CmsKit.Users
{
    public interface ICmsUserRepository: IUserRepository<CmsUser>
    {

    }
}
