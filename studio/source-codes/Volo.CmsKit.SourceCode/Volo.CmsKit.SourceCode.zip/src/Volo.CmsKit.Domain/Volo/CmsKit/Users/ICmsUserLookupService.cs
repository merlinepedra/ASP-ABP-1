﻿using Volo.Abp.Users;

namespace Volo.CmsKit.Users
{
    public interface ICmsUserLookupService : IUserLookupService<CmsUser>
    {

    }
}
