﻿namespace Volo.Abp.BlobStoring.Database.EntityFrameworkCore
{
    public class EfCoreContainer_Tests : BlobContainer_Tests<BlobStoringDatabaseEntityFrameworkCoreTestModule>
    {
        
    }
}