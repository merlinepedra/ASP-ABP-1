﻿namespace Volo.Abp.VirtualFileExplorer.Web
{
    public class AbpVirtualFileExplorerOptions
    {
        /// <summary>
        /// Default: true.
        /// </summary>
        public bool IsEnabled { get; set; } = true;
    }
}
